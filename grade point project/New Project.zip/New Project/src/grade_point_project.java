import java.util.Scanner;

public class grade_point_project {
    public static void main(String[] args) {
        // System.out means print to the console
        int grade;

        int going = 0;
        //print ln means print the string at the new line at the end where ln stands for line
        System.out.println("Hello world");


        System.out.println("enter the grade point average.");
        Scanner input = new Scanner(System.in);
        grade = input.nextInt();
        //   going++;


        if (grade < 67) {

            System.out.println("They got an f");
        }
        if (grade > 67 && grade <= 70) {

            System.out.println("They got a d.");
        }
        if (grade > 70 && grade <= 80) {
            System.out.println("They got a c.");
        }

        if (grade > 80 && grade < 90) {
            System.out.println("They got a b");
        }

        if (grade >= 90) {
            System.out.println("They got an A");
        }


        if (grade >= 67) {

            System.out.println("they passed  with a D");

        }


        if (grade < 67) {

            System.out.println("They didn't passz");
           if(grade>90) {System.out.println("they got an A");
        }





    }}}

